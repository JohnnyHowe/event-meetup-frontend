import events from "./events.js";
import users from "./users.js";

export default { events, users };